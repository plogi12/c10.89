var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["81a4f500-ad11-4009-8f0e-175b165af74b","11d5d9f0-6932-45de-ba25-6f4ac37fe9a9","7d58941f-a7d8-42da-85c6-3efa6131461a","42b7aa29-c5f8-44fe-9d49-8540deca9c13","e92d7a76-cb9d-426f-90f2-1f5356f539aa"],"propsByKey":{"81a4f500-ad11-4009-8f0e-175b165af74b":{"name":"ball","sourceUrl":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/81a4f500-ad11-4009-8f0e-175b165af74b.png","frameSize":{"x":20,"y":20},"frameCount":1,"looping":true,"frameDelay":4,"version":"VhkehIKvl9Li0ucH0_v5BxrJscBTMWI7","loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":20},"rootRelativePath":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/81a4f500-ad11-4009-8f0e-175b165af74b.png"},"11d5d9f0-6932-45de-ba25-6f4ac37fe9a9":{"name":"robot","sourceUrl":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/11d5d9f0-6932-45de-ba25-6f4ac37fe9a9.png","frameSize":{"x":77,"y":69},"frameCount":1,"looping":true,"frameDelay":4,"version":"zaUlPQ5T3tdDvx0d3gEjPV.389TexZEO","loadedFromSource":true,"saved":true,"sourceSize":{"x":77,"y":69},"rootRelativePath":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/11d5d9f0-6932-45de-ba25-6f4ac37fe9a9.png"},"7d58941f-a7d8-42da-85c6-3efa6131461a":{"name":"player","sourceUrl":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/7d58941f-a7d8-42da-85c6-3efa6131461a.png","frameSize":{"x":60,"y":91},"frameCount":1,"looping":true,"frameDelay":4,"version":"8zH62MLCfZl0pjpq.AxsQbCoctObiDOS","loadedFromSource":true,"saved":true,"sourceSize":{"x":60,"y":91},"rootRelativePath":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/7d58941f-a7d8-42da-85c6-3efa6131461a.png"},"42b7aa29-c5f8-44fe-9d49-8540deca9c13":{"name":"player_kick","sourceUrl":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/42b7aa29-c5f8-44fe-9d49-8540deca9c13.png","frameSize":{"x":77,"y":77},"frameCount":1,"looping":true,"frameDelay":4,"version":"TB4tygqti7cEXzgDABqUXKN4WdyBpM.C","loadedFromSource":true,"saved":true,"sourceSize":{"x":77,"y":77},"rootRelativePath":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/42b7aa29-c5f8-44fe-9d49-8540deca9c13.png"},"e92d7a76-cb9d-426f-90f2-1f5356f539aa":{"name":"player_fall","sourceUrl":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/e92d7a76-cb9d-426f-90f2-1f5356f539aa.png","frameSize":{"x":92,"y":51},"frameCount":1,"looping":true,"frameDelay":4,"version":"ASZNmtadv1Msf_fgS3TnIHmjqaTV1e92","loadedFromSource":true,"saved":true,"sourceSize":{"x":92,"y":51},"rootRelativePath":"assets/v3/animations/-avJdgAUNRjyTsnOFCs8c0UqlTsKHiEVHv4fvZZZiKA/e92d7a76-cb9d-426f-90f2-1f5356f539aa.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


//crear paddle y ball - paleta y pelota
var paddle = createSprite(200, 375, 100, 20);
var ball = createSprite(150, 250, 10, 1);
var gameState = "serve";
var score=0;

//primera fila de cajas
var box1 = createSprite(24, 75, 30, 30);
box1.shapeColor="purple";
var box2 = createSprite(74, 75, 30, 30);
box2.shapeColor="blue";
var box3 = createSprite(124, 75, 30, 30);
box3.shapeColor="purple";
var box4 = createSprite(174, 75, 30, 30);
box4.shapeColor="blue";
var box5 = createSprite(224, 75, 30, 30);
box5.shapeColor="purple";
var box6 = createSprite(274, 75, 30, 30);
box6.shapeColor="blue";
var box7 = createSprite(324, 75, 30, 30);
box7.shapeColor="purple";
var box8 = createSprite(374, 75, 30, 30);
box8.shapeColor="blue";

//segunda fila de cajas
var box9 = createSprite(24, 125, 30, 30);
box9.shapeColor="blue";
var box10 = createSprite(74, 125, 30, 30);
box10.shapeColor="purple";
var box11 = createSprite(124, 125, 30, 30);
box11.shapeColor="blue";
var box12 = createSprite(174, 125, 30, 30);
box12.shapeColor="purple";
var box13 = createSprite(224, 125, 30, 30);
box13.shapeColor="blue";
var box14 = createSprite(274, 125, 30, 30);
box14.shapeColor="purple";
var box15 = createSprite(324, 125, 30, 30);
box15.shapeColor="blue";
var box16 = createSprite(374, 125, 30, 30);
box16.shapeColor="purple";


function draw() {
  background("yellow");
  
  //mostrar puntuación
  textSize(15);
  stroke("red");
  text("Puntuación :"+score,280,20);
  
  
  
  if(gameState === "serve"){
    text("Press Star Or Game ",100,200);
    if(keyDown("enter")){
    ball.velocityX = 5;
    ball.velocityY = 6;
    gameState= "play";
   }
  }
  if(gameState ==="play"){
    createEdgeSprites();
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(paddle);

  //Mover la paleta con el mouse a lo largo del eje x
  paddle.x=World.mouseX;
  
  //destruir las cajas cuando tocan la pelota
  if(ball.isTouching(box1))
  {
    score=score+1;
    box1.destroy();
  }
  
  if(ball.isTouching(box2))
  {
    score=score+1;
    box2.destroy();
  }
  
  if(ball.isTouching(box3))
  {
    score=score+1;
    box3.destroy();
  }
  
  if(ball.isTouching(box4))
  {
    score=score+1;
    box4.destroy();
  }
  
  if(ball.isTouching(box5))
  {
    score=score+1;
    box5.destroy();
  }
  
  if(ball.isTouching(box6))
  {
    score=score+10;
    box6.destroy();
  }
  
  if(ball.isTouching(box7))
  {
    score=score+11;
    box7.destroy();
  }
  
  if(ball.isTouching(box8))
  {
    score=score+10;
    box8.destroy();
  }
  
  if(ball.isTouching(box9))
  {
    score=score+1;
    box9.destroy();
  }
  
  if(ball.isTouching(box10))
  {
    score=score+1;
    box10.destroy();
  }
  if(ball.isTouching(box11))
  {
    score=score+1;
    box11.destroy();
  }
  if(ball.isTouching(box12))
  {
    score=score+1;
    box12.destroy();
  }
  if(ball.isTouching(box13))
  {
    score=score+10;
    box13.destroy();
  }
  if(ball.isTouching(box14))
  {
    score=score-1;
    box14.destroy();
  }
  if(ball.isTouching(box15))
  {
    score=score-1;
    box15.destroy();
  }
  if(ball.isTouching(box16))
  {
    score=score+10;
    box16.destroy();
  }
    if(ball.isTouching(bottomEdge))
     {
       gameState="end"
  }
  }
  if(gameState === "end"){
    
    
  }
  
  //Mover la pelota al presionar la tecla enter
  
  
  //Hacer que la pelota rebote en la paleta y en tres lados del lienzo
  
  
  drawSprites();
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
